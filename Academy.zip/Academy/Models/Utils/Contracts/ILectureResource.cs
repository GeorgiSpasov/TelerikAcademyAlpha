﻿namespace Academy.Models.Contracts
{
    public interface ILectureResource
    {
        string Name { get; set; }

        string Url { get; set; }
    }
}
