﻿namespace Academy.Core.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
